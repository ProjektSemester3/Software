/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

CY_ISR(isr_rx)
{
    LED_Write(!LED_Read());
    uint8 buffer;
    SPIS_1_ClearRxBuffer();
    buffer = SPIS_1_ReadRxData();
    SPIS_1_ClearTxBuffer();
    SPIS_1_WriteTxData(buffer);
    UART_1_WriteTxData(buffer);
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    SPIS_1_Start();
    isr_1_StartEx(isr_rx);
    UART_1_Start();
    

    for(;;)
    {
        
    }
}

/* [] END OF FILE */
