#include "project.h"
#include <stdio.h>

uint8 status;

void updateStatus(uint8);
void writeToXY(uint8);
void writeToZ(uint8);   // Sensor used on x-axis is also used on z-axis

enum SPI_protocol {
    
    // Commands from DK8k to PSoC-master/from PSoC-master to -slaves
    GET_STATUS = 0x00,
    LOCATE_XY = 0x01,
    LOCATE_Z_1 = 0x02,
    LOCATE_Z_2 = 0x03,
    OPEN_BOTTLE = 0x04,
    
    // Command from PSoC-master to -slaves
    RESET = 0x05,
    DISPENSE_CORK = 0x06,
    
    // Feedback messages from PSoC-slaves to -master
    VALID_XY = 0x10,
    INVALID_XY = 0x20,
    RESET_XY_ON_SUCCESS = 0x35, // Only if bottle has been opened
    MOVED_Z_1 = 0x11,
    MOVED_Z_2 = 0x12,
    VALID_Z = 0x13,
    RESET_Z = 0x34,
    OPENING_SUCCESSFUL = 0x15,
    CORK_DISPENSED = 0x16,
    READY_TO_DRINK = 0x17,
    
    // Feedback messages from PSoC-master to DK8k/from PSoC-slaves to -master
    VALID_TYPE = 0x14,
    INVALID_TYPE = 0x21,
    NO_BOTTLE = 0x22,
    DEFAULT = 0x30,
    WRONG_COMMAND = 0x31,
    WRONG_DEVICE = 0x32,
    IN_PROCESS = 0x33,
};

CY_ISR(isr_RxD)
{
    uint8 cmd;
    
    cmd = UART_1_ReadRxData();
    UART_1_ClearRxBuffer();
    
    cmd -= 0x30;
    
    switch(cmd) {
            
        // Write status of bottle to DK8k
		case GET_STATUS:
		    updateStatus(status);
            
            if(status != IN_PROCESS || status != VALID_TYPE) {
                status = DEFAULT;
            }
		    break;
        
        // Registrate bottle
	    case LOCATE_XY:
            updateStatus(IN_PROCESS);
            
            SS_1_Write(0);
            // Validate thickness of bottle neck
            writeToXY(cmd);
            SS_1_Write(1);
			break;
        
        // Open bottle
        case RESET:
            
            SS_1_Write(0);
            writeToXY(cmd);
            SS_1_Write(1);
            break;
        
        // Unidentified command
        default:
            UART_1_WriteTxData(WRONG_COMMAND);
            UART_1_ClearTxBuffer();
            break;
	}
}

CY_ISR(isr_1)
{
    uint8 fb;
    fb = SPIM_1_ReadRxData();
    SPIM_1_ClearRxBuffer();
    
    switch(fb) {
        
        // Thickness of bottle neck OK
        case VALID_XY:
            
            // Position x-sensor to just under top of bottle
            updateStatus(fb);
            break;
        
        // X- and y-sensor positioned to start-positions on respectively x- and y-axes
        case RESET_XY_ON_SUCCESS:
            
            // Dispense of cork
            updateStatus(fb);
            break;
        
        default:
            updateStatus(fb);
            break;
    }
}

int main()
{
    updateStatus(DEFAULT);
    CyGlobalIntEnable;

    UART_1_Start();
    isr_RxD_StartEx(isr_RxD);
    
    SPIM_1_Start();
    SPIM_1_EnableRxInt();
    isr_1_StartEx(isr_1);
	SPIM_1_ClearFIFO();
	SPIM_1_ClearTxBuffer();

    for(;;)
    {
    }
}

// Update status of master-PSoC/message to be sent to DK8k
void updateStatus(uint8 stat)
{
    status = stat;
    UART_1_WriteTxData(status);
}

// Write command to PSoC-slave 1
void writeToXY(uint8 cmd)
{
    SPIM_1_ClearTxBuffer();
    SPIM_1_WriteTxData(cmd);
}

/* [] END OF FILE */
