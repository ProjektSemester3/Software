#include "project.h"
#include <stdio.h>

uint8 xStep = 0b1100; // Start position for motor - global variable
uint8 yStep = 0b1100; // Start position for motor - global variable
uint16 xStepCount = 0;
uint16 yStepCount = 0;
uint8 enabled = 0;
uint8 status;

int8 locateX();
int8 locateY();
void motorRunLeft(uint8);
void motorRunRight(uint8);

enum SPI_protocol {
    
    // Commands from DK8k to PSoC
    GET_STATUS = 0x00,
    OPEN_BOTTLE = 0x01,
    
    // Feedback messages from PSoC to DK8k
    VALID_TYPE = 0x10,
    INVALID_TYPE = 0x20,
    NO_BOTTLE = 0x21,
    OPENING_SUCCESSFUL = 0x11,
    OPENING_UNSUCCESSFUL = 0x22,
    DEFAULT = 0x30,
    WRONG_COMMANDO = 0x31,
    WRONG_DEVICE = 0x32,
    IN_PROCESS = 0x33,
};

enum bottleInfo {
    MIN_WIDTH = 2,      // Random value
    MAX_WIDTH = 5,      // Random value
    OFF_EDGE = 10,      // Random value
};

enum voltageBoundary {
    HIGH = 134,        // Random value
    LOW = 72,          // Random value
};

enum axes {
    X = 0,
    Y = 1,
};

CY_ISR(isr_1)
{
    uint16 rxvalue;
	uint8 cmd;
	uint8 addr;
    
    rxvalue = SPIS_1_ReadRxData(); // This also clears Rx Status Register
    
    /* Protocol - Write 8-bit: 
	 * |CMD|  ADDR  |    DATA    |
	 *  1 1 1      8 7          0
	 *	5 4 3
	 */

	/* Protocol - Read 16-bit: 
	 * |CMD|  ADDR  |  Not Used  |       |           DATA          |
	 *  1 1 1      8 7          0         1                       0
	 *	5 4 3                             5
	 */
    
    cmd = (rxvalue >> 14) & 0x3;  // cmd = rdvalue[15:14]
	addr = (rxvalue >> 8) & 0x3f; // addr = rdvalue[13:8]
    enabled = 1;
    Pin_LED_Write(!Pin_LED_Read());
    
    switch (addr) {
		case 0x1:
			switch(cmd) {
                
                // Write status of bottle to DK8k
				case GET_STATUS:
					SPIS_1_ClearTxBuffer();
					SPIS_1_WriteTxData(status);
					break;
                
                // Begin the process of opening the bottle
				case OPEN_BOTTLE:
                    enabled = 1;
					break;
                
                // Unidentified command
                default:
                    SPIS_1_ClearTxBuffer();
                    SPIS_1_WriteTxData(WRONG_COMMANDO);
                    break;
            }
			break;
        
        // Unidentified address
		default:
			SPIS_1_ClearTxBuffer();
            SPIS_1_WriteTxData(WRONG_DEVICE);
			break;
	}
}

uint8 rotateRight(uint8 value)      // Shifter bit en til højre
{
    return  (value >> 1) | ( (value << 3) & 15);
}

uint8 rotateLeft(uint8 value)      // Shifter bit en til venstre
{
    return  (value >> 3) | ( (value << 1) & 15);
}


int main()
{
    status = DEFAULT;
    CyGlobalIntEnable;
    
    SPIS_1_Start();
	SPIS_1_EnableRxInt();
    isr_1_StartEx(isr_1);
	SPIS_1_ClearFIFO();
	SPIS_1_ClearTxBuffer();

    for(;;)
    {
        if(enabled) {
            status = IN_PROCESS;
            
            // Locate bottle on x-axis
            if(locateX()) {
                enabled = 0;
                break;
            }
            
            // Locate bottle on y-axis
            //if(locateY()) {
            //    enabled = 0;
            //    break;
            //}
            
            // Make slave-PSoC ready to open bottle
            
            enabled = 0;
        }
    }
    
    return 0;
}

int8 locateX()
{
    uint16 ADCResultX;
    uint16 i;
    uint16 xPosRight = 0;
    uint16 xPosLeft = 0;
    uint16 xWidth = 0;
    
    // Start sensor
    ADC_SAR_Seq_1_Start();
    ADC_SAR_Seq_1_StartConvert();
    ADC_SAR_Seq_1_IsEndConversion(ADC_SAR_Seq_1_WAIT_FOR_RESULT);
    
    // Find right edge of bottle
    do {
        ADCResultX = ADC_SAR_Seq_1_GetResult16(0);
        motorRunLeft(X);
    } while((ADCResultX < LOW));
    
    xPosRight = xStepCount;
    
    // Find left edge of bottle
    do {
        ADCResultX = ADC_SAR_Seq_1_GetResult16(0);
        motorRunLeft(X);
    } while((ADCResultX > LOW));
    
    xPosLeft = xStepCount;
    
    ADC_SAR_Seq_1_Stop();
    
    xWidth = (xPosLeft - xPosRight)/2;
    
    // Bottle of incorrect type
    if((xWidth < MIN_WIDTH) || (xWidth > MAX_WIDTH)) {
        status = INVALID_TYPE;
        //return -1;
    }
    
    // Find mid-point
    for(i = xWidth; i > 0; --i) {
        motorRunRight(X);
    }
    
    // Success
    return 0;
}

void motorRunLeft(uint8 axis)
{
    int i;
    if(axis == X) {
        for(i = 0; i < 10; i++) {
            xStep = rotateLeft(xStep);
            Coils_Write(xStep);              // Skriver til pins fra TopDesign (Coils)
            CyDelay(2);
        }
        ++xStepCount;
    }
    else {
        
    }
}

void motorRunRight(uint8 axis)
{
    if(axis == X) {
        xStep = rotateRight(xStep);
        Coils_Write(xStep);              // Skriver til pins fra TopDesign (Coils)
        --xStepCount;
        CyDelay(2);
    }
    else {
    }
}
